-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2020-11-15 11:40:12
-- 服务器版本： 10.4.14-MariaDB
-- PHP 版本： 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `shop`
--

-- --------------------------------------------------------

--
-- 表的结构 `backstage`
--

CREATE TABLE `backstage` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `rolename` varchar(15) NOT NULL,
  `roledescribe` varchar(15) NOT NULL,
  `lv` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `backstage`
--

INSERT INTO `backstage` (`id`, `username`, `password`, `rolename`, `roledescribe`, `lv`) VALUES
(1, '测试3', '123456', '系统管理员', '系统管理员', '1'),
(2, '测试4', '123456', '系统管理员2', '系统管理员2', '2'),
(3, '测试5', '123456', '副主管', '技术负责人', '2'),
(4, 'admin', '123456', '超级管理员', '超级管理员', '0'),
(5, '测试2', '123456', '测试角色5', '测试角色', '2'),
(6, '测试3', '123456', '测试角色3', '测试角色3', '3');

-- --------------------------------------------------------

--
-- 表的结构 `catalogue_detail`
--

CREATE TABLE `catalogue_detail` (
  `id` int(11) NOT NULL,
  `cat_pid` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `pics_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `catalogue_detail`
--

INSERT INTO `catalogue_detail` (`id`, `cat_pid`, `cat_id`, `pics_id`) VALUES
(1, 1, 1, 1),
(2, 1, 1, 2),
(3, 1, 1, 3),
(4, 1, 1, 4),
(5, 1, 1, 5),
(6, 1, 1, 6),
(7, 1, 1, 7),
(8, 1, 1, 8),
(9, 1, 1, 9),
(10, 1, 1, 10),
(11, 1, 2, 51),
(12, 1, 2, 52),
(13, 1, 2, 53),
(14, 1, 2, 54),
(15, 1, 2, 55),
(16, 1, 2, 56),
(17, 1, 2, 57),
(18, 1, 2, 58);

-- --------------------------------------------------------

--
-- 表的结构 `catalogue_detail_pics`
--

CREATE TABLE `catalogue_detail_pics` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `pics_id` int(11) NOT NULL,
  `goods_sales` int(11) NOT NULL,
  `goods_price` int(11) NOT NULL,
  `goods_price2` int(11) NOT NULL,
  `goods_introduce` varchar(30) NOT NULL,
  `goods_img_first` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `catalogue_detail_pics`
--

INSERT INTO `catalogue_detail_pics` (`id`, `cat_id`, `pics_id`, `goods_sales`, `goods_price`, `goods_price2`, `goods_introduce`, `goods_img_first`) VALUES
(1, 1, 1, 830, 158, 0, '颈袖添香高端品牌春秋季修身包臀开叉职业正装气质中袖红色连衣裙', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/1.webp'),
(2, 1, 2, 738, 198, 0, '2020春秋装新款妈妈气质V领大码中长连衣裙女修身宴会晚礼服', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/2.webp'),
(3, 1, 3, 1931, 299, 7, '优衣库 女装 法兰绒A字型连衣裙(长袖)(格子) 43250', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/3.webp'),
(4, 1, 4, 679, 299, 7, '优衣库 【设计师合作款】女装 系带连衣裙(长袖) 43046', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/4.webp'),
(5, 1, 5, 4040, 243, 0, '秋季套装女2020年新款洋气减龄遮肚子显瘦长袖阔太太两件套连', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/5.webp'),
(6, 1, 6, 235, 379, 5, '  乐町气质约会连衣裙2020新款秋中长款气质拼接长袖连衣裙', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/6.webp'),
(7, 1, 7, 457, 299, 0, 'Vero Moda秋装2020年新款流行薄绒运动休闲减龄修身', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/7.webp'),
(8, 1, 8, 490, 569, 6, '伊芙丽假两件连衣裙2020新款秋冬装yifuli显瘦长袖格子', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/8.webp'),
(9, 1, 9, 96, 258, 0, '2020女装夏大红色大摆沙滩气质雪纺及到脚踝超长款超仙连衣裙', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/9.webp'),
(10, 1, 10, 361, 319, 5, '【山海经系列】乐町炸街连衣裙2020新款秋季女装系带翻领连衣', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1/10.webp'),
(11, 2, 51, 1023, 190, 0, '  Massimo Dutti女装 素色棉质 T恤白色T恤女', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/1.webp'),
(12, 2, 52, 849, 79, 0, '2020秋装新款长袖v领女士黑色上衣t恤打底衫女装立领体恤纯', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/2.webp'),
(13, 2, 53, 901, 79, 0, '黑白条纹打底衫女长袖宽松秋冬韩版加绒厚学生堆堆领高领磨毛t恤', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/3.webp'),
(14, 2, 54, 3003, 92, 0, '欧洲站2020新款女装欧货潮白色t恤短袖纯棉打底衫女秋冬洋气', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/4.webp'),
(15, 2, 55, 705, 98, 0, '网纱打底衫女长袖半高领 春秋内搭上衣百搭修身加绒t恤洋气小衫', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/5.webp'),
(16, 2, 56, 693, 89, 0, '新款长袖T恤女春秋大码女装妈妈遮肚子宽松加绒上衣中长款打底衫', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/6.webp'),
(17, 2, 57, 597, 69, 0, '中长款宽松大码女装春秋条纹长袖纯棉t恤上衣秋装新款打底衫女秋', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/7.webp'),
(18, 2, 58, 14000, 39, 0, '打底衫女内搭秋冬半高领长袖修身2020上衣黑色纯色紧身棉白色', 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2/8.webp');

-- --------------------------------------------------------

--
-- 表的结构 `catalogue_tuijian`
--

CREATE TABLE `catalogue_tuijian` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `catalogue_tuijian`
--

INSERT INTO `catalogue_tuijian` (`id`, `name`, `category_id`) VALUES
(1, '为您推荐', 0),
(2, '女装', 1),
(3, '女鞋', 2),
(4, '男装', 3),
(5, '男鞋', 4),
(6, '手机', 5),
(7, '数码', 6),
(8, '家电', 7),
(9, '美妆', 8),
(10, '箱包', 9),
(11, '运动', 10),
(12, '户外', 11),
(13, '家装', 12),
(14, '家纺', 13),
(15, '居家百货', 14),
(16, '鲜花宠物', 15),
(17, '配饰', 16),
(18, '食品', 17);

-- --------------------------------------------------------

--
-- 表的结构 `catalogue_tuijian2`
--

CREATE TABLE `catalogue_tuijian2` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name_id` varchar(11) NOT NULL,
  `cat_pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `catalogue_tuijian2`
--

INSERT INTO `catalogue_tuijian2` (`id`, `category_id`, `name_id`, `cat_pid`) VALUES
(1, 0, '女装', 1),
(2, 0, '女鞋', 2),
(3, 0, '男装', 3),
(4, 0, '家电', 4),
(5, 0, '美妆', 5),
(6, 1, '风格馆', 6),
(7, 1, '气质裙装', 7),
(8, 1, '时尚内搭', 8),
(9, 1, '百搭裤装', 9),
(10, 1, '特色服装', 10),
(11, 1, '潮流外套', 11),
(12, 2, '运动悠闲鞋', 12),
(13, 2, '高跟鞋', 13),
(14, 3, 'T恤', 14),
(15, 3, '外套', 15),
(16, 4, '凉鞋', 16),
(17, 4, '拖鞋', 17),
(18, 5, '热门品牌', 18),
(19, 6, '摄影摄像', 19),
(20, 7, '烟机灶具', 20),
(21, 7, '烟机灶具', 21),
(22, 8, '护肤馆', 9999),
(23, 9, '女包', 9999),
(24, 10, '跑步鞋', 9999),
(25, 11, '户外服装', 9999),
(26, 12, '照明灯饰', 9999),
(27, 13, '床品套件', 9999),
(28, 14, '当季热卖', 9999),
(29, 15, '鲜花园艺', 9999),
(30, 16, '珠宝', 9999),
(31, 17, '进口食品', 9999);

-- --------------------------------------------------------

--
-- 表的结构 `catalogue_tuijian3`
--

CREATE TABLE `catalogue_tuijian3` (
  `id` int(11) NOT NULL,
  `cat_pid` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `title` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `catalogue_tuijian3`
--

INSERT INTO `catalogue_tuijian3` (`id`, `cat_pid`, `cat_id`, `icon`, `title`) VALUES
(1, 1, 1, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv1.webp', '连衣裙'),
(2, 1, 2, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv2.webp', 'T恤'),
(3, 1, 3, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv3.webp', '衬衫'),
(4, 1, 4, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv4.webp', '雪纺衫'),
(5, 1, 5, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv5.webp', '裤子'),
(6, 1, 6, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvzhuang/nv6.webp', '牛仔裤'),
(7, 2, 7, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvxie/nx1.webp', '小白鞋'),
(8, 2, 8, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvxie/nx2.webp', '乐福鞋'),
(9, 2, 9, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nvxie/nx3.webp', '草编鞋'),
(10, 3, 10, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nanzhuang/nz1.webp', 'T恤'),
(11, 3, 11, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nanzhuang/nz2.webp', '衬衫'),
(12, 3, 12, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nanzhuang/nz3.webp', 'POLO衫'),
(13, 3, 13, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nanzhuang/nz4.webp', '夹克'),
(14, 3, 14, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nanzhuang/nz5.webp', '悠闲裤'),
(15, 3, 15, 'http://127.0.0.1:3000/images/Catalogue/tuijian/nanzhuang/nz6.webp', '牛仔裤'),
(16, 4, 10, 'http://127.0.0.1:3000/images/Catalogue/tuijian/jiadian/jd1.webp', '平板电视'),
(17, 4, 11, 'http://127.0.0.1:3000/images/Catalogue/tuijian/jiadian/jd2.webp', '洗衣机'),
(18, 4, 12, 'http://127.0.0.1:3000/images/Catalogue/tuijian/jiadian/jd3.webp', '冰箱'),
(19, 4, 13, 'http://127.0.0.1:3000/images/Catalogue/tuijian/jiadian/jd4.webp', '电饭煲'),
(20, 4, 14, 'http://127.0.0.1:3000/images/Catalogue/tuijian/jiadian/jd5.webp', '空气净化器'),
(21, 4, 15, 'http://127.0.0.1:3000/images/Catalogue/tuijian/jiadian/jd6.webp', '扫地机器人'),
(22, 5, 16, 'http://127.0.0.1:3000/images/Catalogue/tuijian/meizhuang/mz1.webp', '护肤套餐'),
(23, 5, 17, 'http://127.0.0.1:3000/images/Catalogue/tuijian/meizhuang/mz2.webp', '面膜'),
(24, 5, 18, 'http://127.0.0.1:3000/images/Catalogue/tuijian/meizhuang/mz3.webp', '身体护理'),
(25, 6, 19, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/fgg/fgg1.webp', '欧美风'),
(26, 6, 20, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/fgg/fgg2.webp', '文艺风'),
(27, 6, 21, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/fgg/fgg3.webp', '工装风'),
(28, 6, 22, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/fgg/fgg4.webp', '甜美风'),
(29, 6, 23, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/fgg/fgg5.webp', '学院风'),
(30, 6, 24, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/fgg/fgg6.webp', '小香风'),
(31, 7, 25, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz1.webp', '金丝绒连衣裙'),
(32, 7, 26, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz2.webp', '小香风连衣裙'),
(33, 7, 27, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz3.webp', '宴会连衣裙'),
(34, 7, 28, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz4.webp', '中国风连衣裙'),
(35, 7, 29, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz5.webp', '波点连衣裙'),
(36, 7, 30, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz6.webp', '欧根纱连衣裙'),
(37, 7, 31, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz7.webp', '不规则连衣裙'),
(38, 7, 32, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz8.webp', '古风连衣裙'),
(39, 7, 33, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz9.webp', '海边度假连衣裙'),
(40, 7, 34, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz10.webp', '金丝绒半身裙'),
(41, 7, 35, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz11.webp', '针织款半身裙'),
(42, 7, 36, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/qzqz/qzqz12.webp', '鱼尾半身裙'),
(43, 8, 37, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/ssnd/ssnd1.webp', '衬衫'),
(44, 8, 38, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/ssnd/ssnd2.webp', '雪纺衫'),
(45, 8, 39, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/ssnd/ssnd3.webp', '蕾丝衫'),
(46, 8, 40, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/ssnd/ssnd4.webp', 'T恤'),
(47, 8, 41, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/ssnd/ssnd5.webp', '针织衫'),
(48, 8, 42, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/ssnd/ssnd6.webp', '毛衣'),
(49, 9, 43, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz1.webp', '衬衫'),
(50, 9, 44, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz2.webp', '雪纺衫'),
(51, 9, 45, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz3.webp', '蕾丝衫'),
(52, 9, 46, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz4.webp', 'T恤'),
(53, 9, 47, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz5.webp', '针织衫'),
(54, 9, 48, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz6.webp', '毛衣'),
(55, 9, 49, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz7.webp', '衬衫'),
(56, 9, 50, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz8.webp', '雪纺衫'),
(57, 9, 51, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz9.webp', '蕾丝衫'),
(58, 9, 52, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz10.webp', 'T恤'),
(59, 9, 53, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz11.webp', '针织衫'),
(60, 9, 54, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/bdkz/bdkz12.webp', '毛衣'),
(61, 10, 43, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz1.webp', '中老年女装'),
(62, 10, 44, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz2.webp', '大码女装'),
(63, 10, 45, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz3.webp', '设计师原创品牌'),
(64, 10, 46, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz4.webp', '休闲套装'),
(65, 10, 47, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz5.webp', '职业套装'),
(66, 10, 48, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz6.webp', '时尚套装'),
(67, 10, 49, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz7.webp', '民族服饰'),
(68, 10, 50, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz8.webp', '舞台服装'),
(69, 10, 51, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/tsfz/tsfz9.webp', '婚纱'),
(70, 11, 52, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt1.webp', '中老年女装'),
(71, 11, 53, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt2.webp', '大码女装'),
(72, 11, 54, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt3.webp', '设计师原创品牌'),
(73, 11, 55, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt4.webp', '休闲套装'),
(74, 11, 56, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt5.webp', '职业套装'),
(75, 11, 57, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt6.webp', '时尚套装'),
(76, 11, 58, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt7.webp', '民族服饰'),
(77, 11, 59, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt8.webp', '舞台服装'),
(78, 11, 60, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt9.webp', '婚纱'),
(79, 11, 61, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt10.webp', '民族服饰'),
(80, 11, 62, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt11.webp', '舞台服装'),
(81, 11, 63, 'http://127.0.0.1:3000/images/Catalogue/nvzhuang/clwt/clwt12.webp', '婚纱'),
(82, 12, 64, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ydyxx/ydyxx01.webp', '小白鞋'),
(83, 12, 65, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ydyxx/ydyxx02.webp', '板鞋'),
(84, 12, 66, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ydyxx/ydyxx03.webp', '帆布鞋'),
(85, 12, 67, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ydyxx/ydyxx04.webp', '船鞋'),
(86, 12, 68, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ydyxx/ydyxx05.webp', '豆豆鞋'),
(87, 12, 69, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ydyxx/ydyxx06.webp', '运动鞋'),
(88, 13, 70, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ggx/ggx01.webp', '细根'),
(89, 13, 71, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ggx/ggx02.webp', '粗根'),
(90, 13, 72, 'http://127.0.0.1:3000/images/Catalogue/nvxie/ggx/ggx03.webp', '坡根'),
(91, 14, 73, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/Txue/Txue01.webp', '短袖T恤'),
(92, 14, 74, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/Txue/Txue02.webp', '长袖T恤'),
(93, 14, 75, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/Txue/Txue03.webp', 'POLO衫'),
(94, 14, 76, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/Txue/Txue04.webp', '情侣T恤'),
(95, 14, 77, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/Txue/Txue05.webp', '纯棉T恤'),
(96, 14, 78, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/Txue/Txue06.webp', '冰丝T恤'),
(97, 15, 79, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/waitao/waitao01.webp', '男士外套'),
(98, 15, 80, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/waitao/waitao02.webp', '夹克'),
(99, 15, 81, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/waitao/waitao03.webp', '牛仔外套'),
(100, 15, 82, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/waitao/waitao04.webp', '防嗮衣'),
(101, 15, 83, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/waitao/waitao05.webp', '风衣'),
(102, 15, 84, 'http://127.0.0.1:3000/images/Catalogue/nanzhuang/waitao/waitao06.webp', '棒球服'),
(103, 16, 85, 'http://127.0.0.1:3000/images/Catalogue/nanxie/lx/lx01.webp', '沙滩凉鞋'),
(104, 16, 86, 'http://127.0.0.1:3000/images/Catalogue/nanxie/lx/lx02.webp', '洞洞鞋'),
(105, 16, 87, 'http://127.0.0.1:3000/images/Catalogue/nanxie/lx/lx03.webp', '凉鞋'),
(106, 16, 91, 'http://127.0.0.1:3000/images/Catalogue/nanxie/ssyd/ssyd01.webp', '沙滩凉鞋'),
(107, 17, 88, 'http://127.0.0.1:3000/images/Catalogue/nanxie/lx/lx04.webp', '人字拖'),
(108, 17, 89, 'http://127.0.0.1:3000/images/Catalogue/nanxie/lx/lx05.webp', '一字拖'),
(109, 17, 92, 'http://127.0.0.1:3000/images/Catalogue/nanxie/ssyd/ssyd02.webp', '洞洞鞋'),
(110, 17, 93, 'http://127.0.0.1:3000/images/Catalogue/nanxie/ssyd/ssyd03.webp', '包头托'),
(111, 18, 94, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji01.webp', 'IPone'),
(112, 18, 95, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji02.webp', '小米'),
(113, 18, 96, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji03.webp', '荣耀'),
(114, 18, 97, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji04.webp', '华为'),
(115, 18, 98, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji05.webp', 'OPPO'),
(116, 18, 99, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji06.webp', '努比亚'),
(117, 18, 100, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji07.webp', 'vivo'),
(118, 18, 101, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji08.webp', 'AGM'),
(119, 18, 102, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji09.webp', '三星'),
(120, 18, 103, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji10.webp', 'MOTO'),
(121, 18, 104, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji11.webp', '魅族'),
(122, 18, 105, 'http://127.0.0.1:3000/images/Catalogue/shouji/shouji12.webp', '诺基亚'),
(123, 19, 106, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx01.webp', '自拍相机'),
(124, 19, 107, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx02.webp', '数码相机'),
(125, 19, 108, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx03.webp', '微单'),
(126, 19, 109, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx04.webp', '单反'),
(127, 19, 110, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx05.webp', '镜头'),
(128, 19, 111, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx06.webp', '拍立得'),
(129, 19, 112, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx07.webp', '摄像机'),
(130, 19, 113, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx08.webp', '佳能'),
(131, 19, 114, 'http://127.0.0.1:3000/images/Catalogue/shuma/sysx/sysx09.webp', '尼康'),
(132, 20, 115, 'http://127.0.0.1:3000/images/Catalogue/jiadian/szcj/szcj01.webp', '燃气灶'),
(133, 20, 116, 'http://127.0.0.1:3000/images/Catalogue/jiadian/szcj/szcj02.webp', '油烟机'),
(134, 20, 117, 'http://127.0.0.1:3000/images/Catalogue/jiadian/szcj/szcj03.webp', '洗碗机'),
(135, 20, 118, 'http://127.0.0.1:3000/images/Catalogue/jiadian/szcj/szcj04.webp', '消毒柜'),
(136, 20, 119, 'http://127.0.0.1:3000/images/Catalogue/jiadian/szcj/szcj05.webp', '烟灶套餐'),
(137, 20, 120, 'http://127.0.0.1:3000/images/Catalogue/jiadian/szcj/szcj06.webp', '热水器'),
(138, 21, 121, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq01.webp', '净水器'),
(139, 21, 122, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq02.webp', '电饭煲'),
(140, 21, 123, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq03.webp', '榨汁机'),
(141, 21, 124, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq04.webp', '豆浆机'),
(142, 21, 125, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq05.webp', '电热水壶'),
(143, 21, 126, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq06.webp', '电烤箱'),
(144, 21, 127, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq07.webp', '料理机'),
(145, 21, 128, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq08.webp', '电压力锅'),
(146, 21, 129, 'http://127.0.0.1:3000/images/Catalogue/jiadian/cfdq/cfdq09.webp', '电池炉'),
(147, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(148, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(149, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(150, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(151, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(152, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(153, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(154, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(155, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试'),
(156, 9999, 9999, 'http://127.0.0.1:3000/images/cs1.jpg', '测试');

-- --------------------------------------------------------

--
-- 表的结构 `logon`
--

CREATE TABLE `logon` (
  `user_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `logon`
--

INSERT INTO `logon` (`user_id`, `username`, `password`, `state`, `id`) VALUES
(0, 'admin', '123456', 1, 1),
(1, '18878868888', '123456', 0, 2),
(2, 'xsd1212', '123456', 0, 3),
(3, '100860', '123456', 1, 4),
(4, 'awedmiwen', '123456', 1, 5),
(5, 'a131311', '1211212', 0, 6);

--
-- 转储表的索引
--

--
-- 表的索引 `backstage`
--
ALTER TABLE `backstage`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `catalogue_detail`
--
ALTER TABLE `catalogue_detail`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `catalogue_detail_pics`
--
ALTER TABLE `catalogue_detail_pics`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `catalogue_tuijian`
--
ALTER TABLE `catalogue_tuijian`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `catalogue_tuijian2`
--
ALTER TABLE `catalogue_tuijian2`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `catalogue_tuijian3`
--
ALTER TABLE `catalogue_tuijian3`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `logon`
--
ALTER TABLE `logon`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `backstage`
--
ALTER TABLE `backstage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `catalogue_detail`
--
ALTER TABLE `catalogue_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- 使用表AUTO_INCREMENT `catalogue_detail_pics`
--
ALTER TABLE `catalogue_detail_pics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- 使用表AUTO_INCREMENT `catalogue_tuijian`
--
ALTER TABLE `catalogue_tuijian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- 使用表AUTO_INCREMENT `catalogue_tuijian2`
--
ALTER TABLE `catalogue_tuijian2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- 使用表AUTO_INCREMENT `catalogue_tuijian3`
--
ALTER TABLE `catalogue_tuijian3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- 使用表AUTO_INCREMENT `logon`
--
ALTER TABLE `logon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
